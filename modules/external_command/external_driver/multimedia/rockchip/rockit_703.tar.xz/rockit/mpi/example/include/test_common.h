/*
 * Copyright 2020 Rockchip Electronics Co. LTD
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef SRC_TESTS_RT_MPI_COMMON_TEST_COMMON_H_
#define SRC_TESTS_RT_MPI_COMMON_TEST_COMMON_H_

#include "rk_type.h"

#ifndef RK_SAFE_FREE
#define RK_SAFE_FREE(p)    { if (p) {free(p); (p)=RK_NULL;} }
#endif

#ifndef RK_SAFE_DELETE
#define RK_SAFE_DELETE(p)  { if (p) {delete(p); (p)=NULL;} }
#endif

#define RGB(r, g, b)       (((RK_U8)(r) << 16) | ((RK_U8)(g) << 8) | (RK_U8)(b))

typedef enum rkTEST_MPI_SOURCE_E {
    TEST_MPI_SOURCE_SEND = 0,
    TEST_MPI_SOURCE_BIND,
    TEST_MPI_SOURCE_BUTT
} TEST_MPI_SOURCE_E;

#endif  // SRC_TESTS_RT_MPI_COMMON_TEST_COMMON_H_
