/* GPL-2.0 WITH Linux-syscall-note OR Apache 2.0 */
/* Copyright (c) 2021 Fuzhou Rockchip Electronics Co., Ltd */

#ifndef INCLUDE_RT_MPI_MPI_COMM_AIO_H_
#define INCLUDE_RT_MPI_MPI_COMM_AIO_H_

#include "rk_common.h"
#include "rk_comm_mb.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif  /* __cplusplus */

#define MAX_AUDIO_FILE_PATH_LEN 256
#define MAX_AUDIO_FILE_NAME_LEN 256
#define MAX_ARRAY_NUM 16
#define MAX_SOUND_CARD_CHANNEL 32

/*
 * G726 bitrate and bitdepth map:
 *  bitrate :  16000  24000 32000 40000
 * bit depth:    2     3     4      5
 */
typedef enum rkAUDIO_G726_BPS_E {
    G726_BPS_16K   = 16000,     // 2bit
    G726_BPS_24K   = 24000,     // 3bit
    G726_BPS_32K   = 32000,     // 4bit
    G726_BPS_40K   = 40000,     // 5bit
    G726_BPS_BUTT,
} AUDIO_G726_BPS;

typedef enum rkAUDIO_SAMPLE_RATE_E {
    AUDIO_SAMPLE_RATE_DISABLE = 0,
    AUDIO_SAMPLE_RATE_8000   = 8000,    /* 8K samplerate*/
    AUDIO_SAMPLE_RATE_12000  = 12000,   /* 12K samplerate*/
    AUDIO_SAMPLE_RATE_11025  = 11025,   /* 11.025K samplerate*/
    AUDIO_SAMPLE_RATE_16000  = 16000,   /* 16K samplerate*/
    AUDIO_SAMPLE_RATE_22050  = 22050,   /* 22.050K samplerate*/
    AUDIO_SAMPLE_RATE_24000  = 24000,   /* 24K samplerate*/
    AUDIO_SAMPLE_RATE_32000  = 32000,   /* 32K samplerate*/
    AUDIO_SAMPLE_RATE_44100  = 44100,   /* 44.1K samplerate*/
    AUDIO_SAMPLE_RATE_48000  = 48000,   /* 48K samplerate*/
    AUDIO_SAMPLE_RATE_64000  = 64000,   /* 64K samplerate*/
    AUDIO_SAMPLE_RATE_96000  = 96000,   /* 96K samplerate*/
    AUDIO_SAMPLE_RATE_BUTT,
} AUDIO_SAMPLE_RATE_E;

typedef struct rkAUDIO_STREAM_S {
    MB_BLK pMbBlk;
    RK_U32 u32Len; /* stream lenth, by bytes */
    RK_U64 u64TimeStamp; /* frame time stamp*/
    RK_U32 u32Seq; /* frame seq,if stream is not a valid frame, u32Seq is 0*/
    RK_BOOL bBypassMbBlk; /* FALSE: copy, TRUE: MbBlock owned by internal */
} AUDIO_STREAM_S;

typedef enum rkAUDIO_BIT_WIDTH_E {
    AUDIO_BIT_WIDTH_8   = 0,   /* 8bit width */
    AUDIO_BIT_WIDTH_16  = 1,   /* 16bit width */
    AUDIO_BIT_WIDTH_24  = 2,   /* 24bit width */
    AUDIO_BIT_WIDTH_32  = 3,   /* 32bit width */
    AUDIO_BIT_WIDTH_FLT = 4,   /* float, 32bit width */
    AUDIO_BIT_WIDTH_BUTT,
} AUDIO_BIT_WIDTH_E;

typedef enum rkAIO_SOUND_MODE_E {
    AUDIO_SOUND_MODE_MONO   = 0,/*mono*/
    AUDIO_SOUND_MODE_STEREO = 1,/*stereo*/
    AUDIO_SOUND_MODE_4_CHN  = 4,
    AUDIO_SOUND_MODE_6_CHN  = 6,
    AUDIO_SOUND_MODE_8_CHN  = 8,
    AUDIO_SOUND_MODE_BUTT
} AUDIO_SOUND_MODE_E;

typedef enum rkAUDIO_CHN_MODE_E {
    AUDIO_CHN_MODE_LEFT   = 10,
    AUDIO_CHN_MODE_RIGHT  = 11,
    AUDIO_CHN_MODE_BUTT
} AUDIO_CHN_MODE_E;

typedef enum rkAUDIO_LOOPBACK_MODE_E {
    AUDIO_LOOPBACK_NONE = 0,        /* audio no use loopback */
    AUDIO_LOOPBACK_SW_MICL_REFR,    /* audio use software loopback (Mic Left + Ref Right) */
    AUDIO_LOOPBACK_SW_REFL_MICR,    /* audio use software loopback (Ref Left + Mic Right) */
    AUDIO_LOOPBACK_BUTT
} AUDIO_LOOPBACK_MODE_E;

typedef enum rkAUDIO_CHN_ATTR_MODE_E {
    AUDIO_CHN_ATTR_PPM  = 1,
    AUDIO_CHN_ATTR_RATE = 2,
    AUDIO_CHN_ATTR_BUTT
} AUDIO_CHN_ATTR_MODE_E;

typedef struct rkAUDIO_FRAME_S {
    MB_BLK              pMbBlk;
    AUDIO_BIT_WIDTH_E   enBitWidth;     /*audio frame bitwidth*/
    AUDIO_SOUND_MODE_E  enSoundMode;    /*audio frame momo or stereo mode*/
    RK_U64              u64TimeStamp;   /*audio frame timestamp*/
    RK_U32              u32Seq;         /*audio frame seq*/
    RK_U32              u32Len;         /*data lenth per channel in frame, u32Len <= 0 mean eos*/
    RK_BOOL             bBypassMbBlk; /* FALSE: copy, TRUE: MbBlock owned by internal */
    RK_S32              s32SampleRate;  /*audio frame sampleRate*/
} AUDIO_FRAME_S;

typedef struct rkAEC_FRAME_S {
    AUDIO_FRAME_S   stRefFrame;   /* AEC reference audio frame */
    RK_BOOL         bValid;       /* whether frame is valid */
    RK_BOOL         bSysBind;     /* whether is sysbind */
} AEC_FRAME_S;

typedef struct rkAUDIO_FRAME_INFO_S {
    AUDIO_FRAME_S *pstFrame;/*frame ptr*/
    RK_U32         u32Id;   /*frame id*/
} AUDIO_FRAME_INFO_S;

typedef struct rkAUDIO_ADENC_PARAM_S {
    RK_U8          *pu8InBuf;
    RK_U32          u32InLen;
    RK_U64          u64InTimeStamp;

    RK_U8          *pu8OutBuf;
    RK_U32          u32OutLen;
    RK_U64          u64OutTimeStamp;
} AUDIO_ADENC_PARAM_S;

typedef enum rkAIO_MODE_E {
    AIO_MODE_I2S_MASTER  = 0,   /* AIO I2S master mode */
    AIO_MODE_I2S_SLAVE,         /* AIO I2S slave mode */
    AIO_MODE_PCM_SLAVE_STD,     /* AIO PCM slave standard mode */
    AIO_MODE_PCM_SLAVE_NSTD,    /* AIO PCM slave non-standard mode */
    AIO_MODE_PCM_MASTER_STD,    /* AIO PCM master standard mode */
    AIO_MODE_PCM_MASTER_NSTD,   /* AIO PCM master non-standard mode */
    AIO_MODE_BUTT
} AIO_MODE_E;

typedef struct rkAIO_SOUND_CARD {
    RK_U32  channels;
    RK_U32  sampleRate;
    AUDIO_BIT_WIDTH_E bitWidth;
} AIO_SOUND_CARD;

typedef struct rkAIO_ATTR_S {
    // params of sound card
    AIO_SOUND_CARD      soundCard;
    // input data sample rate
    AUDIO_SAMPLE_RATE_E enSamplerate;
    // bitwidth
    AUDIO_BIT_WIDTH_E   enBitwidth;
    // momo or steror
    AUDIO_SOUND_MODE_E  enSoundmode;
    /* expand 8bit to 16bit,use AI_EXPAND(only valid for AI 8bit),
     * use AI_CUT(only valid for extern Codec for 24bit)
     */
    RK_U32              u32EXFlag;
    /* frame num in buf[2,MAX_AUDIO_FRAME_NUM] */
    RK_U32              u32FrmNum;
    /*
     * point num per frame (80/160/240/320/480/1024/2048)
     * (ADPCM IMA should add 1 point, AMR only support 160)
     */
    RK_U32              u32PtNumPerFrm;
    RK_U32              u32ChnCnt;      /* channle number on FS, valid value:1/2/4/8 */
    /*
     * name of sound card, if it is setted, we will
     * using it to open sound card, otherwise, use
     * the index of device to open sound card
     */
    RK_U8               u8CardName[64];
    RK_U8               u8MapOutChns[AI_MAX_CHN_NUM];
    RK_U8               u8MapChns[AI_MAX_CHN_NUM][MAX_SOUND_CARD_CHANNEL];
    RK_BOOL             bMultichnFlag;
    RK_S32              s32DevQueLen;
} AIO_ATTR_S;

typedef struct rkAI_CHN_PARAM_S {
    RK_S32 s32UsrFrmDepth;
    RK_S32 s32UsrFrmCount;
    AUDIO_LOOPBACK_MODE_E enLoopbackMode;
    RK_U32 u32MapPtNumPerFrm;
    AUDIO_SAMPLE_RATE_E enSamplerate;
    RK_S32 s32SedQueLen;
} AI_CHN_PARAM_S;

typedef struct rkAO_CHN_PARAM_S {
    AUDIO_CHN_MODE_E  enMode;
    AUDIO_LOOPBACK_MODE_E enLoopbackMode;
} AO_CHN_PARAM_S;

typedef struct rkAI_CHN_ATTR_S {
    AUDIO_CHN_ATTR_MODE_E  enChnAttr;
    union {
        RK_S32  s32Ppm;
        RK_U32  u32SampleRate;
    };
} AI_CHN_ATTR_S;

typedef struct rkAO_CHN_ATTR_S {
    AUDIO_CHN_ATTR_MODE_E  enChnAttr;
    union {
        RK_S32  s32Ppm;
        RK_U32  u32SampleRate;
    };
} AO_CHN_ATTR_S;

typedef struct rkAO_CHN_STATE_S {
    RK_U32              u32ChnTotalNum;    /* total number of channel buffer */
    RK_U32              u32ChnFreeNum;     /* free number of channel buffer */
    RK_U32              u32ChnBusyNum;     /* busy number of channel buffer */
} AO_CHN_STATE_S;

typedef enum rkAUDIO_TRACK_MODE_E {
    AUDIO_TRACK_NORMAL      = 0,
    AUDIO_TRACK_BOTH_LEFT   = 1,
    AUDIO_TRACK_BOTH_RIGHT  = 2,
    AUDIO_TRACK_EXCHANGE    = 3,
    AUDIO_TRACK_MIX         = 4,
    AUDIO_TRACK_LEFT_MUTE   = 5,
    AUDIO_TRACK_RIGHT_MUTE  = 6,
    AUDIO_TRACK_BOTH_MUTE   = 7,
    AUDIO_TRACK_FRONT_LEFT  = 8,
    AUDIO_TRACK_FRONT_RIGHT = 9,
    AUDIO_TRACK_OUT_STEREO  = 10,

    AUDIO_TRACK_BUTT
} AUDIO_TRACK_MODE_E;

typedef enum rkAUDIO_FADE_RATE_E {
    AUDIO_FADE_RATE_1   = 0,
    AUDIO_FADE_RATE_2   = 1,
    AUDIO_FADE_RATE_4   = 2,
    AUDIO_FADE_RATE_8   = 3,
    AUDIO_FADE_RATE_16  = 4,
    AUDIO_FADE_RATE_32  = 5,
    AUDIO_FADE_RATE_64  = 6,
    AUDIO_FADE_RATE_128 = 7,

    AUDIO_FADE_RATE_BUTT
} AUDIO_FADE_RATE_E;

typedef struct rkAUDIO_FADE_S {
    RK_BOOL         bFade;
    AUDIO_FADE_RATE_E enFadeInRate;
    AUDIO_FADE_RATE_E enFadeOutRate;
} AUDIO_FADE_S;

typedef enum rkAUDIO_VOLUME_CURVE_E {
    AUDIO_CURVE_UNSET     = 0,
    AUDIO_CURVE_LINEAR    = 1,
    AUDIO_CURVE_LOGARITHM = 2,
    AUDIO_CURVE_CUSTOMIZE = 3,

    AUDIO_CURVE_BUTT
} AUDIO_VOLUME_CURVE_E;

typedef struct rkAUDIO_VOLUME_CURVE_S {
    AUDIO_VOLUME_CURVE_E enCurveType;
    RK_S32               s32Resolution;
    RK_FLOAT             fMinDB;
    RK_FLOAT             fMaxDB;
    RK_U32              *pCurveTable;
} AUDIO_VOLUME_CURVE_S;

/*Defines the configure parameters of AI saving file.*/
typedef struct rkAUDIO_SAVE_FILE_INFO_S {
    RK_BOOL     bCfg;
    RK_CHAR     aFilePath[MAX_AUDIO_FILE_PATH_LEN];
    RK_CHAR     aFileName[MAX_AUDIO_FILE_NAME_LEN];
    RK_U32      u32FileSize;  /*in KB*/
} AUDIO_SAVE_FILE_INFO_S;

/*Defines whether the file is saving or not .*/
typedef struct rkAUDIO_FILE_STATUS_S {
    RK_BOOL     bSaving;
} AUDIO_FILE_STATUS_S;

typedef enum rkAIO_VQE_CONFIG_METHOD  {
    AIO_VQE_CONFIG_NONE,
    AIO_VQE_CONFIG_USER,       // user set all configs by parameters
    AIO_VQE_CONFIG_LOAD_FILE,  // read and parse config file
} AIO_VQE_CONFIG_METHOD;

typedef enum rkAI_VQE_TYPE_S {
    AI_VQE_NONE = 0,
    AI_VQE_RECORD,
    AI_VQE_TALK,
} AI_VQE_TYPE_S;

typedef struct rkAI_VQE_MOD_ENABLE_S {
    RK_BOOL bAec;
    RK_BOOL bBf;
    RK_BOOL bFastAec;
    RK_BOOL bAes;
    RK_BOOL bWakeup;
    RK_BOOL bGsc;
    RK_BOOL bAgc;
    RK_BOOL bAnr;
    RK_BOOL bNlp;
    RK_BOOL bDereverb;
    RK_BOOL bCng;
    RK_BOOL bDtd;
    RK_BOOL bEq;
    RK_BOOL bHowling;
    RK_BOOL bDoa;
    RK_BOOL bAinr;
} AI_VQE_MOD_ENABLE_S;

/**Defines the configure parameters of ANR.*/
typedef struct rkAUDIO_ANR_CONFIG_S {
    RK_FLOAT    fNoiseFactor;
    RK_S32      s32SwU;
    RK_FLOAT    fPsiMin;
    RK_FLOAT    fPsiMax;
    RK_FLOAT    fGmin;
    short       supFreq1;
    short       supFreq2;
    RK_FLOAT    fSupEnergy1;
    RK_FLOAT    fSupEnergy2;
    short       interV;
    RK_FLOAT    fBiasMin;
    short       updateFrm;
    RK_FLOAT    fNPreGammaThr;
    RK_FLOAT    fNPreZetaThr;
    RK_FLOAT    fSabsGammaThr0;
    RK_FLOAT    fSabsGammaThr1;
    RK_FLOAT    fInfSmooth;
    RK_FLOAT    fProbSmooth;
    RK_FLOAT    fCompCoeff;
    RK_FLOAT    fPrioriMin;
    RK_FLOAT    fPostMax;
    RK_FLOAT    fPrioriRatio;
    RK_FLOAT    fPrioriRatioLow;
    RK_S32      s32SplitBand;
    RK_FLOAT    fPrioriSmooth;
    short       tranMode;
} AUDIO_ANR_CONFIG_S;

typedef struct rkAUDIO_AGC_CONFIG_S {
    RK_FLOAT    fAttackTime;
    RK_FLOAT    fReleaseTime;
    RK_FLOAT    fAttenuateTime;
    RK_FLOAT    fMaxGain;
    RK_FLOAT    fMaxPeak;
    RK_FLOAT    fRth0;
    RK_FLOAT    fRth1;
    RK_FLOAT    fRth2;
    RK_FLOAT    fRk0;
    RK_FLOAT    fRk1;
    RK_FLOAT    fRk2;
    RK_FLOAT    fLineGainDb;
    RK_S32      s32SwSmL0;
    RK_S32      s32SwSmL1;
    RK_S32      s32SwSmL2;
    RK_S32      s32Fs;
    RK_S32      s32Frmlen;
} AUDIO_AGC_CONFIG_S;

typedef struct rkAUDIO_DELAY_CONFIG_S {
    short     maxFrame;
    short     leastDelay;
    short     jumpFrame;
    short     delayOffset;
    short     micAmpThr;
    short     refAmpThr;
    short     startFreq;
    short     endFreq;
    RK_FLOAT  fSmoothFactor;
} AUDIO_DELAY_CONFIG_S;

typedef struct rkAUDIO_AEC_CONFIG_S {
    RK_S32               s32Pos;
    RK_S32               s32DropRefChannel;
    RK_S32               s32ModelAecEn;
    RK_S32               s32DelayLen;
    RK_S32               s32LookAhead;
    short                arrayList[MAX_ARRAY_NUM];
    short                filter_len;
    AUDIO_DELAY_CONFIG_S delay;
} AUDIO_AEC_CONFIG_S;

typedef struct rkAUDIO_DEREVERB_CONFIG_S {
    RK_S32      s32RlsLg;
    RK_S32      s32CurveLg;
    RK_S32      s32Delay;
    RK_FLOAT    fForgetting;
    RK_FLOAT    fT60;
    RK_FLOAT    fCoCoeff;
} AUDIO_DEREVERB_CONFIG_S;

typedef struct rkAUDIO_NLP_CONFIG_S {
    short    nlp16k[8][2];
} AUDIO_NLP_CONFIG_S;

typedef struct rkAUDIO_CNG_CONFIG_S{
    RK_FLOAT    fGain;
    RK_FLOAT    fMpy;
    RK_FLOAT    fSmoothAlpha;
    RK_FLOAT    fSpeechGain;
} AUDIO_CNG_CONFIG_S;

typedef struct rkAUDIO_DTD_CONFIG_S {
    RK_FLOAT    fKsiThdHigh;
    RK_FLOAT    fKsiThdLow;
} AUDIO_DTD_CONFIG_S;

typedef struct rkAUDIO_AES_CONFIG_S {
    RK_FLOAT fBetaUp;
    RK_FLOAT fBetaDown;
    RK_FLOAT fbetaUpLow;
    RK_FLOAT fbetaDownLow;
    short    lowFreq;
    short    highFreq;
    short    thdFlag;
    short    hardFlag;
    RK_FLOAT fLimitRatio[2][3];
    short    thdSplitFreq[4][2];
    RK_FLOAT fThdSupDegree[4][10];
    short    hardSplitFreq[5][2];
    RK_FLOAT fHardThreshold[4];
} AUDIO_AES_CONFIG_S;

typedef struct _AUDIO_HOWL_CONFIG_S {
    short mode;
} AUDIO_HOWL_CONFIG_S;

typedef struct _AUDIO_DOA_CONFIG_S {
    float fRad;
    short startFreq;
    short endFreq;
    short lgNum;
    short lgPitchNum;
} AUDIO_DOA_CONFIG_S;

typedef struct _AUDIO_WKP_CONFIG_S {
    int   s32Mode;           // 0: oneshot, 1: wakeup + command
    int   s32WakeupFrames;   // (default: 180) the frame counts of keeping wakeup and waiting command word
    int   s32WakeupWords;    // the max of wakeup word, which is >= 1
    char  modelWord1[128];    // wakeup word
    char  modelWord2[128];    // command word
} AUDIO_WKP_CONFIG_S;

typedef struct _AUDIO_AINR_CONFIG_S {
    char modelPath[MAX_AUDIO_FILE_PATH_LEN];
} AUDIO_AINR_CONFIG_S;

typedef struct rkAUDIO_BEAM_FORM_CONFIG_S {
    RK_S32      s32ModelEn;
    RK_S32      s32RefPos;
    RK_S32      s32Targ;
    RK_S32      s32NumRefChannel;
    RK_S32      s32DropRefChannel;

    AUDIO_DEREVERB_CONFIG_S dereverb;
    AUDIO_AES_CONFIG_S  aes;
    AUDIO_NLP_CONFIG_S  nlp;
    AUDIO_ANR_CONFIG_S  anr;
    AUDIO_AGC_CONFIG_S  agc;
    AUDIO_CNG_CONFIG_S  cng;
    AUDIO_DTD_CONFIG_S  dtd;
    AUDIO_HOWL_CONFIG_S howl;
    AUDIO_DOA_CONFIG_S  doa;
    AUDIO_WKP_CONFIG_S  wkp;
    AUDIO_AINR_CONFIG_S ainr;
} AUDIO_BEAM_FORM_CONFIG_S;

typedef struct rkAI_VQE_USER_CONFIG_S {
    AUDIO_AEC_CONFIG_S       stAecCfg;
    AUDIO_BEAM_FORM_CONFIG_S stBeamCfg;
} AI_VQE_USER_CONFIG_S;

typedef struct rkAI_VQE_CONFIG_S {
    AIO_VQE_CONFIG_METHOD enCfgMode;  /* see AIO_VQE_CONFIG_METHOD */
    RK_S32                s32WorkSampleRate;    /* Sample Rate: 8KHz/16KHz/48KHz. default: 16KHz*/
    RK_S32                s32FrameSample;       /* VQE frame length, default: 256 frames(16ms,16KHz) */
    RK_S64                s64RefChannelType;    /* Ref channel layout type*/
    RK_S64                s64RecChannelType;    /* Rec channel layout type*/
    RK_S64                s64ChannelLayoutType; /* Channel layout type*/
    union {
        /* config file if enCfgMode = AIO_VQE_CONFIG_LOAD_FILE */
        RK_CHAR           aCfgFile[MAX_AUDIO_FILE_PATH_LEN];
        /* set user' parameters if enCfgMode = AIO_VQE_CONFIG_USER */
        AI_VQE_USER_CONFIG_S  stUsrCfg;
    };
} AI_VQE_CONFIG_S;

typedef struct rkAI_VQE_RESULT_S {
    RK_S32                s32WakeupStatus;
    RK_S32                s32WakeupMode;      /* 0: none; 1: oneshot; 2: wakeup+command; 3: oneshot and wakeup+command */
    RK_S32                s32WakeupCmdID;
    RK_FLOAT              s32WakeupCmdScore;
} AI_VQE_RESULT_S;

typedef struct rkAI_SED_CONFIG_S {
    RK_S64                s64RecChannelType;  /* Rec channel layout type */
    RK_S32                s32FrameLen;        /* If not specified, it will be set 90 by rk_ai_channel. */
    RK_BOOL               bUsed;
} AI_SED_CONFIG_S;

typedef struct rkAI_AED_CONFIG_S {
    RK_FLOAT              fSnrDB;
    RK_FLOAT              fLsdDB;
    RK_S32                s32Policy;
    RK_FLOAT              fSmoothParam;
} AI_AED_CONFIG_S;

typedef struct rkAI_AED_RESULT_S {
    RK_BOOL               bAcousticEventDetected;
    RK_BOOL               bLoudSoundDetected;
    RK_FLOAT              lsdResult;
} AI_AED_RESULT_S;

typedef RK_VOID (*AI_BCD_CB)(void);

typedef struct rkAI_BCD_CONFIG_S {
    RK_S32                mFrameLen;       // Statistics frame length, the longer it is, the harder it is to wake up
    RK_S32                mBlankFrameMax;  // Reset the frame length, and re-statistics when the frame length exceeds it
    RK_FLOAT              mCryEnergy;
    RK_FLOAT              mJudgeEnergy;
    RK_FLOAT              mCryThres1;
    RK_FLOAT              mCryThres2;
    RK_FLOAT              mConfirmProb;
    AI_SED_CONFIG_S       stSedCfg;
    union {
        RK_CHAR           aModelPath[MAX_AUDIO_FILE_PATH_LEN];
    };
} AI_BCD_CONFIG_S;

typedef struct rkAI_BCD_RESULT_S {
    RK_BOOL               bBabyCry;
} AI_BCD_RESULT_S;

typedef struct rkAI_BUZ_CONFIG_S {
    RK_S32                mFrameLen;       // Statistics frame length, the longer it is, the harder it is to wake up
    RK_S32                mBlankFrameMax;  // Reset the frame length, and re-statistics when the frame length exceeds it
    RK_FLOAT              mEnergyMean;
    RK_FLOAT              mEnergyMax;
    RK_FLOAT              mBuzThres1;
    RK_FLOAT              mBuzThres2;
    RK_FLOAT              mConfirmProb;
    AI_SED_CONFIG_S       stSedCfg;
} AI_BUZ_CONFIG_S;

typedef struct rkAI_BUZ_RESULT_S {
    RK_BOOL               bBuzz;
} AI_BUZ_RESULT_S;

typedef struct rkAI_GBS_CONFIG_S {
    RK_S32                mFrameLen;       // Statistics frame length, the longer it is, the harder it is to wake up
    RK_FLOAT              mConfirmProb;
    AI_SED_CONFIG_S       stSedCfg;
} AI_GBS_CONFIG_S;

typedef struct rkAI_GBS_RESULT_S {
    RK_BOOL               bGbs;
} AI_GBS_RESULT_S;

typedef enum rkAO_VQE_MASK {
    AO_VQE_MASK_NONE = 1 << 0,
    AO_VQE_MASK_3A   = 1 << 1,
    AO_VQE_MASK_AGC  = 1 << 2,
    AO_VQE_MASK_ANR  = 1 << 3,
} AO_VQE_MASK;

typedef struct rkAO_VQE_USER_CONFIG_S {
    RK_U32                u32OpenMask;          /* see AO_VQE_MASK */

    AUDIO_AGC_CONFIG_S    stAgcCfg;
    AUDIO_ANR_CONFIG_S    stAnrCfg;
    AUDIO_HOWL_CONFIG_S   stHowlCfg;
    RK_S32                s32ModelEn;
} AO_VQE_USER_CONFIG_S;

typedef struct rkAO_VQE_CONFIG_S {
    AIO_VQE_CONFIG_METHOD enCfgMode;  /* see AIO_VQE_CONFIG_METHOD */
    RK_S32                s32WorkSampleRate;    /* Sample Rate: 8KHz/16KHz/48KHz. default: 16KHz*/
    RK_S32                s32FrameSample;       /* VQE frame length, default: 256 frames(16ms,16KHz) */
    union {
        /* config file if enCfgMode = AIO_VQE_CONFIG_LOAD_FILE */
        RK_CHAR               aCfgFile[MAX_AUDIO_FILE_PATH_LEN];
        /* set user' parameters if enCfgMode = AIO_VQE_CONFIG_USER */
        AO_VQE_USER_CONFIG_S  stUsrCfg;
    };
} AO_VQE_CONFIG_S;

typedef enum rkEN_AIO_ERR_CODE_E {
    AIO_ERR_VQE_ERR        = 65 , /*vqe error*/
} RK_AIO_ERR_CODE_E;

/* at lease one parameter is illagal ,eg, an illegal enumeration value  */
#define RK_ERR_AIO_ILLEGAL_PARAM    RK_DEF_ERR(RK_ID_AIO, RK_ERR_LEVEL_ERROR, RK_ERR_ILLEGAL_PARAM)
/* using a NULL point */
#define RK_ERR_AIO_NULL_PTR         RK_DEF_ERR(RK_ID_AIO, RK_ERR_LEVEL_ERROR, RK_ERR_NULL_PTR)
/* operation is not supported by NOW */
#define RK_ERR_AIO_NOT_PERM         RK_DEF_ERR(RK_ID_AIO, RK_ERR_LEVEL_ERROR, RK_ERR_NOT_PERM)
/* vqe  err */
#define RK_ERR_AIO_REGISTER_ERR     RK_DEF_ERR(RK_ID_AIO, RK_ERR_LEVEL_ERROR, AIO_ERR_VQE_ERR)

/* invlalid device ID */
#define RK_ERR_AI_INVALID_DEVID     RK_DEF_ERR(RK_ID_AI, RK_ERR_LEVEL_ERROR, RK_ERR_INVALID_DEVID)
/* invlalid channel ID */
#define RK_ERR_AI_INVALID_CHNID     RK_DEF_ERR(RK_ID_AI, RK_ERR_LEVEL_ERROR, RK_ERR_INVALID_CHNID)
/* at lease one parameter is illagal ,eg, an illegal enumeration value  */
#define RK_ERR_AI_ILLEGAL_PARAM     RK_DEF_ERR(RK_ID_AI, RK_ERR_LEVEL_ERROR, RK_ERR_ILLEGAL_PARAM)
/* using a NULL point */
#define RK_ERR_AI_NULL_PTR          RK_DEF_ERR(RK_ID_AI, RK_ERR_LEVEL_ERROR, RK_ERR_NULL_PTR)
/* try to enable or initialize system,device or channel, before configing attribute */
#define RK_ERR_AI_NOT_CONFIG        RK_DEF_ERR(RK_ID_AI, RK_ERR_LEVEL_ERROR, RK_ERR_NOT_CONFIG)
/* operation is not supported by NOW */
#define RK_ERR_AI_NOT_SUPPORT       RK_DEF_ERR(RK_ID_AI, RK_ERR_LEVEL_ERROR, RK_ERR_NOT_SUPPORT)
/* operation is not permitted ,eg, try to change stati attribute */
#define RK_ERR_AI_NOT_PERM          RK_DEF_ERR(RK_ID_AI, RK_ERR_LEVEL_ERROR, RK_ERR_NOT_PERM)
/* the devide is not enabled  */
#define RK_ERR_AI_NOT_ENABLED       RK_DEF_ERR(RK_ID_AI, RK_ERR_LEVEL_ERROR, RK_ERR_UNEXIST)
/* failure caused by malloc memory */
#define RK_ERR_AI_NOMEM             RK_DEF_ERR(RK_ID_AI, RK_ERR_LEVEL_ERROR, RK_ERR_NOMEM)
/* failure caused by malloc buffer */
#define RK_ERR_AI_NOBUF             RK_DEF_ERR(RK_ID_AI, RK_ERR_LEVEL_ERROR, RK_ERR_NOBUF)
/* no data in buffer */
#define RK_ERR_AI_BUF_EMPTY         RK_DEF_ERR(RK_ID_AI, RK_ERR_LEVEL_ERROR, RK_ERR_BUF_EMPTY)
/* no buffer for new data */
#define RK_ERR_AI_BUF_FULL          RK_DEF_ERR(RK_ID_AI, RK_ERR_LEVEL_ERROR, RK_ERR_BUF_FULL)
/* system is not ready,had not initialed or loaded*/
#define RK_ERR_AI_SYS_NOTREADY      RK_DEF_ERR(RK_ID_AI, RK_ERR_LEVEL_ERROR, RK_ERR_NOTREADY)

#define RK_ERR_AI_BUSY              RK_DEF_ERR(RK_ID_AI, RK_ERR_LEVEL_ERROR, RK_ERR_BUSY)
/* vqe  err */
#define RK_ERR_AI_VQE_ERR           RK_DEF_ERR(RK_ID_AI, RK_ERR_LEVEL_ERROR, AIO_ERR_VQE_ERR)

/* invlalid device ID */
#define RK_ERR_AO_INVALID_DEVID     RK_DEF_ERR(RK_ID_AO, RK_ERR_LEVEL_ERROR, RK_ERR_INVALID_DEVID)
/* invlalid channel ID */
#define RK_ERR_AO_INVALID_CHNID     RK_DEF_ERR(RK_ID_AO, RK_ERR_LEVEL_ERROR, RK_ERR_INVALID_CHNID)
/* at lease one parameter is illagal ,eg, an illegal enumeration value  */
#define RK_ERR_AO_ILLEGAL_PARAM     RK_DEF_ERR(RK_ID_AO, RK_ERR_LEVEL_ERROR, RK_ERR_ILLEGAL_PARAM)
/* using a NULL point */
#define RK_ERR_AO_NULL_PTR          RK_DEF_ERR(RK_ID_AO, RK_ERR_LEVEL_ERROR, RK_ERR_NULL_PTR)
/* try to enable or initialize system,device or channel, before configing attribute */
#define RK_ERR_AO_NOT_CONFIG        RK_DEF_ERR(RK_ID_AO, RK_ERR_LEVEL_ERROR, RK_ERR_NOT_CONFIG)
/* operation is not supported by NOW */
#define RK_ERR_AO_NOT_SUPPORT       RK_DEF_ERR(RK_ID_AO, RK_ERR_LEVEL_ERROR, RK_ERR_NOT_SUPPORT)
/* operation is not permitted ,eg, try to change stati attribute */
#define RK_ERR_AO_NOT_PERM          RK_DEF_ERR(RK_ID_AO, RK_ERR_LEVEL_ERROR, RK_ERR_NOT_PERM)
/* the devide is not enabled  */
#define RK_ERR_AO_NOT_ENABLED       RK_DEF_ERR(RK_ID_AO, RK_ERR_LEVEL_ERROR, RK_ERR_UNEXIST)
/* failure caused by malloc memory */
#define RK_ERR_AO_NOMEM             RK_DEF_ERR(RK_ID_AO, RK_ERR_LEVEL_ERROR, RK_ERR_NOMEM)
/* failure caused by malloc buffer */
#define RK_ERR_AO_NOBUF             RK_DEF_ERR(RK_ID_AO, RK_ERR_LEVEL_ERROR, RK_ERR_NOBUF)
/* no data in buffer */
#define RK_ERR_AO_BUF_EMPTY         RK_DEF_ERR(RK_ID_AO, RK_ERR_LEVEL_ERROR, RK_ERR_BUF_EMPTY)
/* no buffer for new data */
#define RK_ERR_AO_BUF_FULL          RK_DEF_ERR(RK_ID_AO, RK_ERR_LEVEL_ERROR, RK_ERR_BUF_FULL)
/* system is not ready,had not initialed or loaded*/
#define RK_ERR_AO_SYS_NOTREADY      RK_DEF_ERR(RK_ID_AO, RK_ERR_LEVEL_ERROR, RK_ERR_NOTREADY)

#define RK_ERR_AO_BUSY              RK_DEF_ERR(RK_ID_AO, RK_ERR_LEVEL_ERROR, RK_ERR_BUSY)
/* vqe  err */
#define RK_ERR_AO_VQE_ERR           RK_DEF_ERR(RK_ID_AO, RK_ERR_LEVEL_ERROR, AIO_ERR_VQE_ERR)


#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif  /* End of #ifdef __cplusplus */

#endif  // INCLUDE_RT_MPI_MPI_COMM_AIO_H_
