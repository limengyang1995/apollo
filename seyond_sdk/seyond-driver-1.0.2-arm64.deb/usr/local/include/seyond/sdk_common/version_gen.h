/**
 *  Copyright (C) 2021 - Innovusion Inc.
 *
 *  All Rights Reserved.
 *
 *  $Id$
 */
#ifndef CUSTOMER_RELEASE
static const char inno_api_version_g[] = "v1.0.2";
#else
static const char inno_api_version_g[] = "v1.0.2";
#endif

static const char inno_api_build_tag_g[] = "3.102.13-deb";
