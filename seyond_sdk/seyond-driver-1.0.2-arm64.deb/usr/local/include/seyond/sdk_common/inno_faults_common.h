/**
 *  Copyright (C) 2021 - Innovusion Inc.
 *
 *  All Rights Reserved.
 *
 *  $Id$
 */

#ifndef SDK_COMMON_INNO_FAULTS_COMMON_H_
#define SDK_COMMON_INNO_FAULTS_COMMON_H_

#include "seyond/sdk_common/inno_faults_falcon.h"
#include "seyond/sdk_common/inno_faults_robinw.h"
#include "seyond/sdk_common/inno_faults_falconk2.h"
#include "seyond/sdk_common/inno_faults_robinel.h"

#endif  // SDK_COMMON_INNO_FAULTS_COMMON_H_
